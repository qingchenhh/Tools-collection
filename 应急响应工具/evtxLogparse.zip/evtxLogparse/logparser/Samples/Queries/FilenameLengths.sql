SELECT 	STRLEN(Name) AS NameLen,
	COUNT(*) AS Total
FROM C:\*.*
GROUP BY NameLen
ORDER BY Total

	
### 下载地址：

https://github.com/mrknow001/xxl-job-rce/releases/download/2.20/xxl-job-admin-2.2.0.jar

https://github.com/mrknow001/xxl-job-rce/releases/download/2.20/xxl-job-executor-sample-springboot-2.2.0.jar


### 搭建方式

1、本地启动mysql数据库导入tables_xxl_job.sql文件，库名为xxl_job（账号/密码：root/root）

2、java -jar xxl-job-admin-2.2.0.jar

3、java -jar xxl-job-executor-sample-springboot-2.2.0.jar
